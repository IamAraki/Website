import { Label, Reveal, Section } from '@/components/site/Primitives';

const blocks = [
  ['Onboarding', 'Welcome message within 24 hours of payment; 45-minute onboarding call within 3 business days. Day-one expectations: approve scripts within 48 hours, film on the scheduled day, reply within 1 business day, show up to the weekly check-in and the monthly strategy call.'],
  ['Accountability', 'Shared dashboard with posts published, DMs, leads, calls booked and results against the 30/60/90 targets. If you go quiet, we nudge after 48 hours and call after 5 days; delivery dates move if your part is late.'],
  ['Support', 'Slack or WhatsApp for day-to-day, email for contracts and invoices. PM for scheduling and files, strategist for content, DM specialist for leads, founder for strategy and escalation.'],
];

export default function Onboarding() {
  return (
    <Section className="!pt-0">
      <Label>Onboarding & accountability</Label>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-12 border-t border-ink/15 pt-10">
        {blocks.map(([t, d], i) => (
          <Reveal key={t} delay={i * 0.08}>
            <h3 className="sub">{t}</h3>
            <p className="body-lg mt-5">{d}</p>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}