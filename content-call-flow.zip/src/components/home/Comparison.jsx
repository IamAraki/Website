import { Reveal, Section } from '@/components/site/Primitives';
import { MessyShapes, NetworkShapes } from './Shapes';

const today = ['You post when you have time', 'You get views, but no one books a call', 'Your DMs go cold', 'You are the bottleneck for everything'];
const withSystem = ['Your content is linked to a sale', 'Leads are qualified before they reach your calendar', 'You film one day a month', 'You see your results every month'];

function Card({ label, items, art, tinted }) {
  return (
    <div className={`h-full rounded-[24px] border border-ink/10 p-8 md:p-10 grid sm:grid-cols-[1.2fr_1fr] gap-8 items-center ${tinted ? 'bg-sky/40' : 'bg-white'}`}>
      <div>
        <p className="label mb-6">{label}</p>
        <ul className="space-y-3">
          {items.map((t) => (
            <li key={t} className={`flex gap-3 body-lg ${tinted ? 'font-bold' : ''}`}>
              <span className={`mt-[9px] w-1.5 h-1.5 shrink-0 rounded-full ${tinted ? 'bg-ink' : 'bg-ink/30'}`} />{t}
            </li>
          ))}
        </ul>
      </div>
      {art}
    </div>
  );
}

export default function Comparison() {
  return (
    <Section>
      <div className="grid lg:grid-cols-[1fr_auto_1fr] gap-6 items-stretch">
        <Reveal><Card label="Today" items={today} art={<MessyShapes />} /></Reveal>
        <div aria-hidden="true" className="flex items-center justify-center text-3xl font-light rotate-90 lg:rotate-0">→</div>
        <Reveal delay={0.15}><Card tinted label="With the Content-to-Calls System" items={withSystem} art={<NetworkShapes />} /></Reveal>
      </div>
      <div aria-hidden="true" className="text-center text-3xl font-light mt-12">↓</div>
    </Section>
  );
}