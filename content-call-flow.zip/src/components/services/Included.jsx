import { useState } from 'react';
import { Label, Section } from '@/components/site/Primitives';
import { included } from '@/lib/servicesContent';

export default function Included() {
  const tabs = Object.keys(included);
  const [tab, setTab] = useState(tabs[0]);
  return (
    <Section className="!pt-0">
      <Label>Done for you</Label>
      <h2 className="h mb-12">What’s included</h2>
      <div role="tablist" className="flex flex-wrap gap-2 mb-8">
        {tabs.map((t) => (
          <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)}
            className={`nav-link !no-underline rounded-full border border-ink px-5 py-2 transition-colors ${tab === t ? 'bg-ink text-cloud' : 'bg-white hover:bg-lilac/40'}`}>
            {t}
          </button>
        ))}
      </div>
      <div className="card overflow-hidden" role="tabpanel">
        <div className="hidden md:grid grid-cols-[1.1fr_2fr_1fr] gap-6 px-8 py-4 border-b border-ink/15 label !mb-0">
          <span>Deliverable</span><span>What you get</span><span>How often</span>
        </div>
        {included[tab].map(([d, w, h]) => (
          <div key={d} className="grid md:grid-cols-[1.1fr_2fr_1fr] gap-2 md:gap-6 px-8 py-6 border-b last:border-b-0 border-ink/15">
            <p className="body-lg font-bold">{d}</p>
            <p className="body-lg">{w}</p>
            <p className="body-sm"><span className="inline-block bg-sky/50 rounded-full px-3 py-1">{h}</span></p>
          </div>
        ))}
      </div>
    </Section>
  );
}