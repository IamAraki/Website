import { Circles, Label, Placeholder, Reveal, Section } from '@/components/site/Primitives';

export default function Story() {
  return (
    <Section className="!pt-0 overflow-hidden">
      <Circles className="w-[800px] h-[800px] -left-[400px] top-0" />
      <Label>Our story & proof</Label>
      <div className="grid lg:grid-cols-2 gap-4">
        <Reveal className="card p-8 md:p-10">
          <p className="label mb-6">Story</p>
          <p className="body-lg"><Placeholder>[PLACEHOLDER: founder story and why I do this, to be added by owner]</Placeholder></p>
          <p className="label mt-10 mb-4">Credentials</p>
          <Placeholder>[PLACEHOLDER]</Placeholder>
        </Reveal>
        <Reveal delay={0.1} className="grid-paper rounded-[24px] border border-ink/10 p-8 md:p-10">
          <p className="label mb-6">Proof</p>
          <h2 className="h-sm">We are accepting our first 3 founding clients.</h2>
          <p className="body-lg mt-8">We do not have case studies yet, and we will not fake them. Our first 3 clients become our first 3 case studies: client, starting point, result and timeframe, shared openly.</p>
        </Reveal>
      </div>
    </Section>
  );
}