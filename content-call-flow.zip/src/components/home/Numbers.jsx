import { Label, Reveal, Section } from '@/components/site/Primitives';

const facts = [['1', 'shoot day a month'], ['30', 'edited reels a month'], ['4', 'static posts a month'], ['90', 'days to a working system']];

export default function Numbers() {
  return (
    <Section className="!pt-0">
      <Label>The numbers at a glance</Label>
      <Reveal className="grid grid-cols-2 lg:grid-cols-4 border-t border-ink/15">
        {facts.map(([n, t]) => (
          <div key={t} className="py-10 pr-4 lg:px-8 lg:first:pl-0 border-b lg:border-b-0 lg:border-r last:border-r-0 border-ink/15">
            <p className="text-[clamp(72px,10vw,140px)] leading-[0.8] tracking-[0.013em]">{n}</p>
            <p className="body-lg mt-6">{t}</p>
          </div>
        ))}
      </Reveal>
    </Section>
  );
}