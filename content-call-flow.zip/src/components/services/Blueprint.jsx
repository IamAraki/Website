import { useState } from 'react';
import { Plus, Minus } from 'lucide-react';
import { Circles, Label, Section } from '@/components/site/Primitives';
import { pillars } from '@/lib/content';
import { included } from '@/lib/servicesContent';

export default function Blueprint() {
  const [open, setOpen] = useState(0);
  return (
    <Section className="!pt-0 overflow-hidden">
      <Circles className="w-[800px] h-[800px] -right-[380px] -top-20" />
      <Label>The method</Label>
      <h2 className="h mb-14">The Brand Content Blueprint</h2>
      <div className="grid md:grid-cols-2 gap-4 items-start">
        {pillars.map(([name, text], i) => {
          const isOpen = open === i;
          return (
            <div key={name} className="grid-paper rounded-[24px] border border-ink/10 relative">
              <button onClick={() => setOpen(isOpen ? -1 : i)} aria-expanded={isOpen} className="w-full text-left p-8 flex items-start justify-between gap-6">
                <span>
                  <span className="label block mb-4">0{i + 1}</span>
                  <span className="h-sm block">{name}</span>
                  <span className="body-lg block mt-4">{text}</span>
                </span>
                <span className="w-10 h-10 shrink-0 rounded-full border border-ink grid place-items-center bg-white">{isOpen ? <Minus size={16} /> : <Plus size={16} />}</span>
              </button>
              {isOpen && (
                <ul className="px-8 pb-8 space-y-2 border-t border-ink/15 pt-6 mx-8 !px-0">
                  {included[name].map(([d]) => <li key={d} className="body-sm flex gap-3"><span className="mt-[7px] w-1.5 h-1.5 rounded-full bg-ink shrink-0" />{d}</li>)}
                </ul>
              )}
            </div>
          );
        })}
      </div>
    </Section>
  );
}