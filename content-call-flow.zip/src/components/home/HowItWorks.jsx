import { Label, Reveal, Section } from '@/components/site/Primitives';

const steps = ['Content', 'Free playbook or DM keyword', 'Application', 'Qualification call', 'Client'];

export default function HowItWorks() {
  return (
    <Section className="!pt-0">
      <Label>The path from stranger to client</Label>
      <h2 className="h">How it works</h2>
      <Reveal>
        <ol className="mt-14 grid md:grid-cols-5 gap-4">
          {steps.map((s, i) => (
            <li key={s} className="relative card p-6 flex md:flex-col items-center md:items-start gap-4 md:min-h-[180px]">
              <span className="w-10 h-10 shrink-0 rounded-full bg-lilac grid place-items-center font-bold body-sm">0{i + 1}</span>
              <span className="body-lg font-bold leading-tight md:mt-auto">{s}</span>
              {i < steps.length - 1 && <span aria-hidden="true" className="hidden md:block absolute -right-[14px] top-1/2 -translate-y-1/2 z-10 text-xl">→</span>}
            </li>
          ))}
        </ol>
      </Reveal>
      <p className="sub mt-12">We track qualified calls booked, not views.</p>
    </Section>
  );
}