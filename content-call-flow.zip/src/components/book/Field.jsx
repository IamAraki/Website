export function Field({ id, label, error, children, note }) {
  return (
    <div>
      <label htmlFor={id} className="block body-sm font-bold mb-2">{label}</label>
      {children}
      {note && <p className="body-sm mt-2 text-ink/80">{note}</p>}
      {error && <p id={`${id}-err`} className="body-sm mt-2 text-destructive">{error}</p>}
    </div>
  );
}

export function Choice({ name, options, value, onChange }) {
  return (
    <div role="radiogroup" id={name} className="flex flex-wrap gap-2">
      {options.map(([v, l]) => (
        <button key={v} type="button" role="radio" aria-checked={value === v} onClick={() => onChange(v)}
          className={`rounded-[10px] border px-4 py-2.5 body-sm text-left transition-colors ${value === v ? 'bg-ink text-cloud border-ink' : 'bg-white border-ink/25 hover:border-ink'}`}>
          {l}
        </button>
      ))}
    </div>
  );
}