import usePageMeta from '@/lib/usePageMeta';
import HomeHero from '@/components/home/HomeHero';
import Comparison from '@/components/home/Comparison';
import ResultPanel from '@/components/home/ResultPanel';
import Numbers from '@/components/home/Numbers';
import HowItWorks from '@/components/home/HowItWorks';
import HubDiagram from '@/components/site/HubDiagram';
import Timeline90 from '@/components/home/Timeline90';
import ForNotFor from '@/components/site/ForNotFor';
import CtaBand from '@/components/site/CtaBand';
import PlaybookBand from '@/components/home/PlaybookBand';

export default function Home() {
  usePageMeta(
    'The Content-to-Calls System | Reverie Works',
    'Done-for-you Instagram content and DM funnels that book qualified sales calls for coaches and service entrepreneurs selling $2,000+ offers.'
  );
  return (
    <>
      <HomeHero />
      <Comparison />
      <ResultPanel />
      <Numbers />
      <HowItWorks />
      <HubDiagram label="The team behind it" title="Seven roles. One engine." />
      <Timeline90 />
      <ForNotFor
        forText="Coaches (fitness, mindset, growth operations, crypto/trading) and service entrepreneurs (growth operators, marketing agency owners) with a working $2,000+ offer, already making sales, roughly $10K to $100K per month."
        notText="People with no offer or sales yet. Offers under $2,000. Anyone who wants overnight virality or guaranteed revenue. Anyone unwilling to film or approve scripts within 48 hours."
      />
      <PlaybookBand />
      <CtaBand />
    </>
  );
}