import usePageMeta from '@/lib/usePageMeta';
import PageHero from '@/components/site/PageHero';
import Thesis from '@/components/about/Thesis';
import Different from '@/components/about/Different';
import HubDiagram from '@/components/site/HubDiagram';
import ForNotFor from '@/components/site/ForNotFor';
import Story from '@/components/about/Story';
import CtaBand from '@/components/site/CtaBand';

export default function About() {
  usePageMeta(
    'About | Reverie Works',
    'Views do not pay bills. Booked calls do. We build the whole path from content to a booked call, and report on calls, not views.'
  );
  return (
    <>
      <PageHero label="About us" title="Views do not pay bills. Booked calls do." sub="We build the whole path from content to a booked call, and report on calls, not views." />
      <Thesis />
      <Different />
      <HubDiagram label="The team structure" title="Seven roles. One engine." footnote="You get the founder on strategy calls and escalations. The team handles daily delivery." />
      <div className="pt-[76px] md:pt-[119px]" />
      <ForNotFor
        label="Who we work with"
        forTitle="Yes"
        notTitle="No"
        forText="Coaches and service entrepreneurs with a working $2,000+ offer, some proof or reviews, a sales process, willingness to film, and clear goals."
        notText="No offer, no budget, wants guaranteed income, will not film, poor reputation, cares more about follower count than booked calls, sells unproven income claims."
      />
      <Story />
      <CtaBand />
    </>
  );
}