const S = { fill: 'none', stroke: '#16112B', strokeWidth: 1 };

export function MessyShapes() {
  return (
    <svg viewBox="0 0 200 160" className="w-full max-w-[240px] mx-auto" aria-hidden="true" {...S}>
      <rect x="88" y="6" width="22" height="22" />
      <rect x="10" y="40" width="40" height="26" transform="rotate(18 30 53)" />
      <path d="M62 94 L80 64 L98 94 Z" />
      <ellipse cx="140" cy="62" rx="18" ry="12" />
      <rect x="180" y="40" width="8" height="40" />
      <rect x="14" y="112" width="52" height="18" rx="9" />
      <rect x="110" y="96" width="18" height="46" transform="rotate(38 119 119)" />
      <rect x="164" y="112" width="20" height="20" rx="5" />
    </svg>
  );
}

const nodes = [[100, 14], [158, 34], [180, 82], [150, 140], [92, 146], [36, 136], [24, 82], [44, 32]];

export function NetworkShapes() {
  const shapes = [
    <rect x="91" y="5" width="18" height="18" />,
    <ellipse cx="158" cy="34" rx="14" ry="10" />,
    <rect x="176" y="66" width="8" height="32" />,
    <rect x="141" y="131" width="18" height="18" rx="5" />,
    <rect x="76" y="140" width="32" height="12" transform="rotate(-6 92 146)" />,
    <rect x="16" y="129" width="40" height="14" rx="7" />,
    <path d="M10 94 L24 70 L38 94 Z" />,
    <rect x="28" y="24" width="32" height="18" />,
  ];
  return (
    <svg viewBox="0 0 200 160" className="w-full max-w-[240px] mx-auto" aria-hidden="true" {...S}>
      {nodes.map(([x, y], i) => {
        const [nx, ny] = nodes[(i + 1) % nodes.length];
        return (
          <g key={i} strokeDasharray="2 3" strokeOpacity="0.7">
            <line x1="100" y1="80" x2={x} y2={y} />
            <line x1={x} y1={y} x2={nx} y2={ny} />
          </g>
        );
      })}
      {shapes.map((s, i) => <g key={i} fill="#fff">{s}</g>)}
      <circle cx="100" cy="80" r="3.5" fill="#fff" />
    </svg>
  );
}