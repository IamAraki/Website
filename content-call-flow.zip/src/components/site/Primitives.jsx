import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

export function Reveal({ children, className = '', delay = 0 }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay }}
    >
      {children}
    </motion.div>
  );
}

export const Label = ({ children, className = '' }) => <p className={`label mb-8 ${className}`}>{children}</p>;

export const PillLink = ({ to = '/book-a-call', children = 'Book a Call', className = '' }) => (
  <Link to={to} className={`btn-pill ${className}`}>{children}</Link>
);

export const GhostLink = ({ to, children }) => (
  <Link to={to} className="ghost-link">{children} <span aria-hidden="true">→</span></Link>
);

export const Placeholder = ({ children }) => <span className="placeholder">{children}</span>;

export const LogoDot = ({ className = '' }) => (
  <span aria-hidden="true" className={`block w-4 h-4 rounded-full bg-sky ring-[5px] ring-lime/70 ${className}`} />
);

export function Section({ children, className = '', id }) {
  return (
    <section id={id} className={`relative px-5 md:px-10 py-[76px] md:py-[119px] ${className}`}>
      <div className="relative mx-auto max-w-[1400px]">{children}</div>
    </section>
  );
}

export function Rings({ radii = [49.5, 37, 24.5, 12], className = '', animateOnLoad = false }) {
  const trigger = animateOnLoad ? { animate: { pathLength: 1, opacity: 1 } } : { whileInView: { pathLength: 1, opacity: 1 }, viewport: { once: true } };
  return (
    <svg viewBox="0 0 100 100" aria-hidden="true" className={`pointer-events-none absolute overflow-visible ${className}`}>
      {radii.map((r, i) => (
        <g key={r} className={i % 2 ? 'orbit-rev' : 'orbit'} style={{ animationDuration: `${40 + i * 15}s` }}>
        <circle cx={50} cy={50 - r} r="0.9" fill="#16112B" fillOpacity="0.45" vectorEffect="non-scaling-stroke" />
        <motion.circle cx="50" cy="50" r={r} fill="none" stroke="#16112B" strokeOpacity="0.2" strokeWidth="1" vectorEffect="non-scaling-stroke"
          transform="rotate(-90 50 50)" initial={{ pathLength: 0, opacity: 0 }} {...trigger}
          transition={{ duration: 2.2, ease: [0.22, 1, 0.36, 1], delay: 0.2 + i * 0.25 }} />
        </g>
      ))}
    </svg>
  );
}

export const Circles = ({ className = '' }) => <Rings className={className} />;