import { Label, Reveal, Section } from '@/components/site/Primitives';
import { phases } from '@/lib/servicesContent';

const Row = ({ k, v }) => <p className="body-sm mt-3"><span className="font-bold">{k}</span> {v}</p>;

export default function Roadmap() {
  return (
    <Section className="!pt-0">
      <Label>Delivery roadmap</Label>
      <h2 className="h mb-14">Ninety days, three phases</h2>
      <div className="grid md:grid-cols-3 gap-4 relative">
        <div aria-hidden="true" className="hidden md:block absolute left-0 right-0 top-[19px] border-t border-dashed border-ink/30" />
        {phases.map(([p, name, days, goal, what, you, we], i) => (
          <Reveal key={p} delay={i * 0.1} className="relative">
            <span className="label !mb-0 inline-block bg-lilac rounded-full px-4 py-3 border border-ink/10">{p}</span>
            <div className="card p-8 mt-6">
              <p className="label mb-3 text-ink/70">{days}</p>
              <h3 className="h-sm">{name}</h3>
              <p className="body-lg font-bold mt-6">Goal: {goal}</p>
              <p className="body-lg mt-3">{what}</p>
              <div className="mt-6 pt-4 border-t border-ink/15">
                <Row k="You:" v={you} />
                <Row k="We:" v={we} />
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}