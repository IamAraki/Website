import { Link } from 'react-router-dom';
import { GhostLink, LogoDot } from './Primitives';

const links = [['Home', '/'], ['Services', '/services'], ['About', '/about'], ['Book a Call', '/book-a-call']];

export default function Footer() {
  return (
    <footer className="bg-cloud border-t border-ink/15 px-5 md:px-10 pt-16 pb-10">
      <div className="mx-auto max-w-[1400px]">
        <div className="grid gap-10 md:grid-cols-3 items-start">
          <Link to="/" className="flex items-center gap-3"><LogoDot /><span className="font-bold">Reverie Works</span></Link>
          <ul className="flex flex-wrap gap-x-8 gap-y-3">
            {links.map(([l, to]) => <li key={to}><Link to={to} className="nav-link">{l}</Link></li>)}
          </ul>
          <div className="md:text-right"><GhostLink to="/book-a-call">Book a Call</GhostLink></div>
        </div>
        <div className="mt-14 pt-6 border-t border-ink/15 flex flex-col md:flex-row md:justify-between gap-3 body-sm">
          <p>© 2026 Reverie Works. We only accept clients we can help.</p>
          <a href="https://www.instagram.com/arakiscales?rpxt=MWtvNXFmcDBtZGdxOA==" target="_blank" rel="noopener noreferrer" className="ghost-link">Instagram <span aria-hidden="true">→</span></a>
        </div>
      </div>
    </footer>
  );
}