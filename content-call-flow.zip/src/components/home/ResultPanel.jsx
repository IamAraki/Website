import { Target, Clapperboard, MessageSquare, BarChart3 } from 'lucide-react';
import { Reveal, Section } from '@/components/site/Primitives';
import { pillars } from '@/lib/content';

const meta = [[Target, 'bg-lime'], [Clapperboard, 'bg-candy'], [MessageSquare, 'bg-sky'], [BarChart3, 'bg-lilac']];

export default function ResultPanel() {
  return (
    <Section className="!pt-0">
      <Reveal className="rounded-[28px] bg-sky px-6 md:px-12 py-14 md:py-20">
        <h2 className="h-lg">The Result</h2>
        <p className="body-lg mt-8 max-w-[720px]">
          The Brand Content Blueprint turns your Instagram into a funnel that moves strangers to trust, to a DM conversation, to a booked call.
        </p>
        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {pillars.map(([name, text], i) => {
            const [Icon, badge] = meta[i];
            return (
              <div key={name} className="bg-ink text-cloud rounded-[20px] p-6 min-h-[250px] flex flex-col transition-transform duration-300 hover:-translate-y-1">
                <span className={`w-10 h-10 rounded-xl grid place-items-center text-ink ${badge}`}><Icon size={18} strokeWidth={1.5} aria-hidden="true" /></span>
                <div className="mt-auto pt-10">
                  <p className="label text-cloud/60 mb-3">0{i + 1}</p>
                  <h3 className="text-[26px] leading-none tracking-[0.013em]">{name}</h3>
                  <p className="body-sm text-cloud/80 mt-3">{text}</p>
                </div>
              </div>
            );
          })}
        </div>
      </Reveal>
    </Section>
  );
}