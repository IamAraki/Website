import { roles } from '@/lib/content';
import { Label, Reveal } from './Primitives';

const pos = roles.map((_, i) => {
  const a = (-90 + (360 / roles.length) * i) * (Math.PI / 180);
  return { x: 50 + 38 * Math.cos(a), y: 50 + 40 * Math.sin(a) };
});

const Center = ({ className = '' }) => (
  <div className={`relative rounded-[20px] border-2 border-lime bg-ink px-8 py-8 text-center ${className}`}>
    <span className="label absolute -top-3 left-1/2 -translate-x-1/2 bg-lime text-ink rounded-full px-3 py-1 whitespace-nowrap">The System</span>
    <p className="text-[28px] leading-tight">The Content-to-Calls System</p>
    <p className="label text-cloud/70 mt-4">7 Roles · One Engine</p>
  </div>
);

const Role = ({ i, title, sub }) => (
  <div className="rounded-[20px] bg-[#211a3d] border border-cloud/10 p-5 flex gap-4 transition-colors hover:border-cloud/30">
    <span className="w-8 h-8 shrink-0 rounded-full border border-lime text-lime body-sm grid place-items-center">{i + 1}</span>
    <div><p className="body-lg font-bold leading-tight">{title}</p><p className="body-sm text-cloud/70 mt-1">{sub}</p></div>
  </div>
);

export default function HubDiagram({ label, title, footnote }) {
  return (
    <section className="bg-ink text-cloud px-5 md:px-10 py-[76px] md:py-[119px]">
      <div className="mx-auto max-w-[1400px]">
        <Label>{label}</Label>
        <h2 className="h">{title}</h2>
        <Reveal className="hidden lg:block relative mt-16 h-[680px]">
          <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
            {pos.map((p, i) => <line key={i} x1="50" y1="50" x2={p.x} y2={p.y} stroke="rgba(244,249,255,0.25)" strokeWidth="1" vectorEffect="non-scaling-stroke" />)}
          </svg>
          <Center className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[330px]" />
          {roles.map(([t, s], i) => (
            <div key={t} className="absolute -translate-x-1/2 -translate-y-1/2 w-[270px]" style={{ left: `${pos[i].x}%`, top: `${pos[i].y}%` }}>
              <Role i={i} title={t} sub={s} />
            </div>
          ))}
        </Reveal>
        <div className="lg:hidden mt-12 space-y-3">
          <Center className="mb-6" />
          {roles.map(([t, s], i) => <Role key={t} i={i} title={t} sub={s} />)}
        </div>
        {footnote && <p className="body-lg mt-14 max-w-[720px] text-cloud/85">{footnote}</p>}
      </div>
    </section>
  );
}