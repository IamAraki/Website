import usePageMeta from '@/lib/usePageMeta';
import PageHero from '@/components/site/PageHero';
import NextSteps from '@/components/book/NextSteps';
import ApplicationForm from '@/components/book/ApplicationForm';
import { Section } from '@/components/site/Primitives';

export default function BookCall() {
  usePageMeta(
    'Apply for a Call | Reverie Works',
    'Apply for a call about The Content-to-Calls System. We only accept clients we can help.'
  );
  return (
    <>
      <PageHero cta={false} label="Book a call" title="Apply for a call" sub="We only accept clients we can help. Tell us about your business and we will see if we are a fit." />
      <Section className="!pt-0">
        <div className="grid lg:grid-cols-[1fr_1.5fr] gap-10 lg:gap-16 items-start">
          <NextSteps />
          <div>
            <ApplicationForm />
            <p className="body-sm mt-6 text-ink/80">No guaranteed income, no fake scarcity. Just an honest conversation.</p>
          </div>
        </div>
      </Section>
    </>
  );
}