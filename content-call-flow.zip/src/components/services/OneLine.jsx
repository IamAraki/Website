import { Label, Reveal, Section } from '@/components/site/Primitives';

export default function OneLine() {
  return (
    <Section className="!pt-0">
      <div className="grid lg:grid-cols-[1fr_2fr] gap-8 border-t border-ink/15 pt-10">
        <Label>The one-line offer</Label>
        <Reveal>
          <p className="sub leading-[1.15]">
            We rebuild your offer and profile, turn one shoot day a month into 30 reels, 4 static posts and story sequences, and run a DM funnel that qualifies leads and books them on your calendar. You film once a month. We do the rest, and you see your results every month.
          </p>
        </Reveal>
      </div>
    </Section>
  );
}