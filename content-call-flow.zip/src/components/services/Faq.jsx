import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Label, Section } from '@/components/site/Primitives';
import { faq } from '@/lib/servicesContent';

export default function Faq() {
  return (
    <Section className="!pt-0">
      <div className="grid lg:grid-cols-[1fr_2fr] gap-10">
        <div>
          <Label>Honest answers</Label>
          <h2 className="h">Questions we hear</h2>
        </div>
        <Accordion type="single" collapsible className="border-t border-ink/15">
          {faq.map(([q, a], i) => (
            <AccordionItem key={q} value={`q${i}`} className="border-ink/15">
              <AccordionTrigger className="text-left sub !text-[24px] md:!text-[28px] py-7 hover:no-underline">“{q}”</AccordionTrigger>
              <AccordionContent className="body-lg !text-[18px] pb-7 max-w-[720px]">{a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </Section>
  );
}