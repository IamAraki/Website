import usePageMeta from '@/lib/usePageMeta';
import PageHero from '@/components/site/PageHero';
import OneLine from '@/components/services/OneLine';
import Blueprint from '@/components/services/Blueprint';
import Included from '@/components/services/Included';
import WithYou from '@/components/services/WithYou';
import BonusesNotIncluded from '@/components/services/BonusesNotIncluded';
import Roadmap from '@/components/services/Roadmap';
import Onboarding from '@/components/services/Onboarding';
import Pricing from '@/components/services/Pricing';
import Faq from '@/components/services/Faq';
import CtaBand from '@/components/site/CtaBand';

export default function Services() {
  usePageMeta(
    'Services: The Content-to-Calls System | Reverie Works',
    'What is included in The Content-to-Calls System: offer rebuild, 30 reels a month, DM funnels, lead qualification, monthly reports and pricing.'
  );
  return (
    <>
      <PageHero label="Services" title="The Content-to-Calls System" sub="A done-for-you content and DM funnel service that books qualified calls for coaches and service entrepreneurs selling $2,000+ offers." />
      <OneLine />
      <Blueprint />
      <Included />
      <WithYou />
      <BonusesNotIncluded />
      <Roadmap />
      <Onboarding />
      <Pricing />
      <Faq />
      <CtaBand />
    </>
  );
}