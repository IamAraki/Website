import { motion } from 'framer-motion';
import { PillLink, Rings } from '@/components/site/Primitives';

export default function HomeHero() {
  return (
    <section className="relative min-h-[100svh] flex items-center justify-center px-5 pt-32 pb-24 overflow-hidden">
      <div aria-hidden="true" className="absolute left-1/2 top-1/2 -translate-y-[55%] translate-x-[-25%]" style={{ width: 'min(50vh, 80vw)', height: 'min(50vh, 80vw)' }}>
        <Rings animateOnLoad radii={[49.5, 38, 28.5]} className="-inset-[105%] w-[310%] h-[310%]" />
        <motion.div
          initial={{ opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
          className="absolute inset-0 rounded-full"
          style={{ background: 'var(--chrome)', boxShadow: '70px 50px 140px rgba(169,214,255,0.55), -50px -40px 140px rgba(255,181,232,0.45)' }}
        />
      </div>
      <div className="relative text-center max-w-[1400px]">
        <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, delay: 0.15 }} className="display">
          Turn your Instagram into a booked-calls machine in 90 days
        </motion.h1>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.9, delay: 0.5 }}>
          <p className="mt-10 mx-auto max-w-[620px] text-[18px] md:text-[22px] leading-[1.4]">
            Done-for-you content that moves strangers to booked calls, without ads or daily posting.
          </p>
          <PillLink className="mt-10" />
        </motion.div>
      </div>
      <span className="label absolute bottom-8 right-6 md:right-10">Scroll ↓</span>
    </section>
  );
}