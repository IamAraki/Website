import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Section } from '@/components/site/Primitives';
import usePageMeta from '@/lib/usePageMeta';

const todos = [
  'Application confirmation email (applicants are not app users, so this needs a custom email domain or an external tool)',
  'Booked call reminders 24 hours and 1 hour before (needs the calendar tool from [CALENDAR LINK])',
  'Same-day no-show message with a rebook link',
  'Post-call summary within 1 hour',
];

export default function Admin() {
  usePageMeta('Admin | Reverie Works', 'Applications admin');
  const { data: me, isLoading } = useQuery({ queryKey: ['me'], queryFn: () => base44.auth.me().catch(() => null) });
  const isAdmin = me?.role === 'admin';
  const { data: apps = [] } = useQuery({ queryKey: ['apps'], enabled: isAdmin, queryFn: () => base44.entities.Application.list('-created_date', 100) });
  const { data: leads = [] } = useQuery({ queryKey: ['leads'], enabled: isAdmin, queryFn: () => base44.entities.PlaybookLead.list('-created_date', 100) });

  if (isLoading) return <Section className="!pt-44"><p className="body-lg">Loading…</p></Section>;
  if (!isAdmin) return (
    <Section className="!pt-44">
      <h1 className="h-sm">Admins only</h1>
      <button className="btn-pill mt-8" onClick={() => base44.auth.redirectToLogin(window.location.href)}>Log in</button>
    </Section>
  );

  return (
    <Section className="!pt-44">
      <h1 className="h">Applications</h1>
      <div className="card mt-10 overflow-x-auto">
        <table className="w-full body-sm text-left">
          <thead><tr className="border-b border-ink/15">{['Date', 'Name', 'Email', 'Instagram', 'Revenue', 'Film', 'Invest', 'Status'].map((h) => <th key={h} className="label p-4">{h}</th>)}</tr></thead>
          <tbody>
            {apps.map((a) => (
              <tr key={a.id} className="border-b border-ink/10 align-top">
                <td className="p-4 whitespace-nowrap">{new Date(a.created_date).toLocaleDateString()}</td>
                <td className="p-4 font-bold">{a.name}<details className="font-normal mt-1"><summary className="cursor-pointer text-ink/70">Details</summary><p className="mt-2">{a.website}</p><p>{a.offer_and_price}</p><p>{a.calls_and_close_rate}</p><p>{a.tried_and_result}</p><p>{a.who_closes}</p></details></td>
                <td className="p-4">{a.email}</td><td className="p-4">{a.instagram}</td><td className="p-4">{a.monthly_revenue}</td>
                <td className="p-4">{a.willing_to_film}</td><td className="p-4">{a.ready_to_invest}</td>
                <td className="p-4"><span className={`rounded-full px-3 py-1 ${a.status === 'Not a fit' ? 'bg-candy' : 'bg-sky'}`}>{a.status}</span></td>
              </tr>
            ))}
            {!apps.length && <tr><td colSpan={8} className="p-6">No applications yet.</td></tr>}
          </tbody>
        </table>
      </div>
      <h2 className="h-sm mt-16">Playbook leads ({leads.length})</h2>
      <ul className="mt-6">{leads.map((l) => <li key={l.id} className="body-sm py-2 border-b border-ink/10">{l.email} · {new Date(l.created_date).toLocaleDateString()}</li>)}</ul>
      <h2 className="h-sm mt-16">Email automations: TODO</h2>
      <ul className="mt-6 space-y-2">{todos.map((t) => <li key={t} className="body-sm">☐ {t}</li>)}</ul>
    </Section>
  );
}