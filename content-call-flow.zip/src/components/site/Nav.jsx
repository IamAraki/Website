import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { LogoDot } from './Primitives';

const links = [['HOME', '/'], ['SERVICES', '/services'], ['ABOUT', '/about']];
const cls = ({ isActive }) => `nav-link ${isActive ? 'underline font-bold' : ''}`;

export default function Nav() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  useEffect(() => setOpen(false), [pathname]);

  return (
    <header className="fixed top-5 inset-x-3 md:inset-x-5 z-50">
      <nav aria-label="Main" className="relative mx-auto max-w-[1400px] h-16 md:h-[72px] px-4 md:px-6 flex items-center justify-between bg-white rounded-[24px] shadow-[0_2px_24px_rgba(22,17,43,0.05)]">
        <Link to="/" aria-label="Reverie Works home" className="p-2"><LogoDot /></Link>
        <ul className="hidden md:flex absolute left-1/2 -translate-x-1/2 gap-10">
          {links.map(([l, to]) => <li key={to}><NavLink to={to} end className={cls}>{l}</NavLink></li>)}
        </ul>
        <div className="flex items-center gap-2">
          <Link to="/book-a-call" className="btn-pill !px-5 !py-2.5">Book a Call</Link>
          <button className="md:hidden p-2" onClick={() => setOpen(!open)} aria-label="Toggle menu" aria-expanded={open}>
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </nav>
      {open && (
        <ul className="md:hidden mt-2 bg-white rounded-[24px] p-6 flex flex-col gap-5">
          {links.map(([l, to]) => <li key={to}><NavLink to={to} end className={cls}>{l}</NavLink></li>)}
        </ul>
      )}
    </header>
  );
}