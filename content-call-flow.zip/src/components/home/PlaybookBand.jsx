import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Placeholder, Reveal, Section } from '@/components/site/Primitives';

export default function PlaybookBand() {
  const [email, setEmail] = useState('');
  const [state, setState] = useState('idle');
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) return setError('Please enter a valid email address.');
    setError('');
    setState('sending');
    try {
      await base44.entities.PlaybookLead.create({ email: email.trim() });
      setState('done');
    } catch {
      setState('idle');
      setError('Something went wrong. Please try again.');
    }
  };

  return (
    <Section className="!pt-0">
      <Reveal className="card p-8 md:p-12 grid lg:grid-cols-2 gap-8 items-center">
        <div>
          <p className="label mb-5 inline-block bg-lilac rounded-full px-3 py-1">Free</p>
          <h2 className="h-sm">The Content-to-Calls Playbook</h2>
          <p className="body-sm mt-4 text-ink/70"><Placeholder>[Attach PDF later: PLACEHOLDER]</Placeholder></p>
        </div>
        {state === 'done' ? (
          <p className="sub" role="status">Thanks. Check your inbox.</p>
        ) : (
          <form onSubmit={submit} noValidate>
            <div className="flex flex-col sm:flex-row gap-3">
              <label htmlFor="pb-email" className="sr-only">Email</label>
              <input id="pb-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@business.com" className="field flex-1" aria-invalid={!!error} />
              <button type="submit" disabled={state === 'sending'} className="btn-pill">
                {state === 'sending' ? 'Sending…' : 'Send me the playbook →'}
              </button>
            </div>
            {error && <p className="body-sm text-destructive mt-2">{error}</p>}
          </form>
        )}
      </Reveal>
    </Section>
  );
}