import { Circles, Label, Reveal, Section } from '@/components/site/Primitives';

const items = [
  ['30 days', 'Offer, positioning and profile fixed. Content scripted, shot and live. DM funnel built. First data in, with a baseline for views, leads and calls booked.'],
  ['60 days', 'Content improved based on what the audience responded to. DM funnel refined using real conversations.'],
  ['90 days', 'Top 10% of content found and repeated. Qualified calls booked through the funnel. A clear plan for the next quarter.'],
];

export default function Timeline90() {
  return (
    <Section className="overflow-hidden">
      <Circles className="w-[900px] h-[900px] -left-[420px] -top-40" />
      <Label>30 / 60 / 90 days</Label>
      <div className="grid md:grid-cols-3 gap-4">
        {items.map(([t, d], i) => (
          <Reveal key={t} delay={i * 0.1} className="grid-paper rounded-[24px] border border-ink/10 p-8 min-h-[300px] flex flex-col">
            <h3 className="h-sm">{t}</h3>
            <p className="body-lg mt-auto pt-10">{d}</p>
          </Reveal>
        ))}
      </div>
      <p className="body-sm mt-8 text-ink/75">No one can promise exact results. We show you the numbers every month.</p>
    </Section>
  );
}