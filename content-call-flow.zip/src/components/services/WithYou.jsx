import { Label, Reveal, Section } from '@/components/site/Primitives';
import { withYou, selfServe } from '@/lib/servicesContent';

export default function WithYou() {
  return (
    <Section className="!pt-0">
      <Label>Done with you</Label>
      <h2 className="h mb-12">Working together</h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {withYou.map(([t, d, dur], i) => (
          <Reveal key={t} delay={i * 0.05} className="card p-6 flex flex-col min-h-[230px] hover:border-ink/30 transition-colors">
            <p className="body-lg font-bold leading-tight">{t}</p>
            <p className="body-sm mt-3">{d}</p>
            <p className="label mt-auto pt-6 !mb-0"><span className="bg-lilac rounded-full px-3 py-1 inline-block">{dur}</span></p>
          </Reveal>
        ))}
      </div>
      <div className="mt-[76px] grid lg:grid-cols-[1fr_2fr] gap-8 border-t border-ink/15 pt-10">
        <div><Label>Self-serve tools</Label></div>
        <ul className="grid sm:grid-cols-2 gap-x-8">
          {selfServe.map((s) => <li key={s} className="body-lg py-4 border-b border-ink/15">{s}</li>)}
        </ul>
      </div>
    </Section>
  );
}