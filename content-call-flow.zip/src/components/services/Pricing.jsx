import { Label, PillLink, Reveal, Section } from '@/components/site/Primitives';
import { terms } from '@/lib/servicesContent';

const cards = [
  { tag: 'Founding client', price: '$2,500', lines: ['For the first 3 clients, in exchange for a case study.', '3 founding spots available now.', '3-month minimum.'], tagCls: 'bg-candy' },
  { tag: 'Standard', price: '$5,000', lines: ['3-month minimum, then month-to-month.', 'Pay 3 months upfront for $13,500 (10% off).', 'After the founding spots, 2 new clients per month, with a hard cap of 6 active clients.'], tagCls: 'bg-sky' },
];

export default function Pricing() {
  return (
    <Section className="!pt-0" id="pricing">
      <Label>Pricing</Label>
      <h2 className="h mb-14">Two ways in</h2>
      <div className="grid md:grid-cols-2 gap-4">
        {cards.map((c, i) => (
          <Reveal key={c.tag} delay={i * 0.1} className="grid-paper rounded-[28px] border border-ink/10 p-8 md:p-12">
            <span className={`label inline-block rounded-full px-3 py-1 ${c.tagCls}`}>{c.tag}</span>
            <p className="mt-10"><span className="h-lg">{c.price}</span> <span className="body-lg">per month</span></p>
            <ul className="mt-10 space-y-3">
              {c.lines.map((l) => <li key={l} className="body-lg flex gap-3"><span className="mt-[9px] w-1.5 h-1.5 rounded-full bg-ink shrink-0" />{l}</li>)}
            </ul>
          </Reveal>
        ))}
      </div>
      <div className="mt-10 flex flex-col md:flex-row md:items-center gap-6 justify-between">
        <p className="body-lg">Billed in USD through Stripe or PayPal.</p>
        <PillLink>Apply for a Call</PillLink>
      </div>
      <ul className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-x-8 border-t border-ink/15">
        {terms.map((t) => <li key={t} className="body-sm py-4 border-b border-ink/15">{t}</li>)}
      </ul>
    </Section>
  );
}