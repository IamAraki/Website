import { Label, Reveal, Section } from '@/components/site/Primitives';

const List = ({ title, items, cls }) => (
  <div>
    <p className={`label inline-block rounded-full px-3 py-1 ${cls}`}>{title}</p>
    <ul className="mt-4">{items.map((i) => <li key={i} className="body-lg py-4 border-b border-ink/15">{i}</li>)}</ul>
  </div>
);

export default function Different() {
  return (
    <Section className="!pt-0">
      <Label>What makes us different</Label>
      <div className="grid md:grid-cols-2 gap-4">
        <Reveal className="card p-8 md:p-10"><p className="label mb-6 text-ink/70">Most agencies</p><p className="sub leading-[1.15]">What most agencies do: post content, report views and likes, and leave the sale to you.</p></Reveal>
        <Reveal delay={0.1} className="rounded-[24px] bg-sky/40 border border-ink/10 p-8 md:p-10"><p className="label mb-6">Us</p><p className="sub leading-[1.15]">What we do instead: build and run the whole path from content to a booked call, and report on calls, not views.</p></Reveal>
      </div>
      <div className="mt-4 rounded-[20px] bg-lilac/50 px-8 py-6 body-lg">What we disagree with: that virality equals growth, and that one generalist social media manager can do it all.</div>
      <div className="mt-[76px] grid md:grid-cols-2 gap-12">
        <List title="Stand for" cls="bg-sky" items={['Honest results', 'Value first', 'Quality over noise', 'Long-term trust']} />
        <List title="Will not do" cls="bg-candy" items={['Fake client screenshots', 'Fake scarcity', 'Guaranteed-income claims', 'Working with brands that mislead their audience']} />
      </div>
    </Section>
  );
}