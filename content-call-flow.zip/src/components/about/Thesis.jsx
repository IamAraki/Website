import { GhostLink, Label, Reveal, Section } from '@/components/site/Primitives';

const beliefs = [
  'Views do not pay bills. Booked calls do, so we track conversions, not vanity metrics.',
  'Content must cover the top, middle and bottom of the funnel, so strangers become warm and warm people book.',
  'A system where strategy, content, DMs and reporting work together beats a single freelancer.',
];

export default function Thesis() {
  return (
    <>
      <Section className="!pt-0">
        <div className="grid lg:grid-cols-[1fr_2fr] gap-8 border-t border-ink/15 pt-10">
          <div><Label>Our thesis</Label><GhostLink to="/services">SEE SERVICES</GhostLink></div>
          <Reveal><p className="sub leading-[1.15]">The best way to sell a $2,000+ offer online is a personal brand built on trust and a content-to-calls system, not views.</p></Reveal>
        </div>
      </Section>
      <Section className="!pt-0">
        <Label>What we believe</Label>
        <div className="grid md:grid-cols-3 gap-4">
          {beliefs.map((b, i) => (
            <Reveal key={i} delay={i * 0.1} className="grid-paper rounded-[24px] border border-ink/10 p-8 min-h-[280px] flex flex-col">
              <span className="w-10 h-10 rounded-full bg-lilac grid place-items-center font-bold body-sm">0{i + 1}</span>
              <p className="body-lg mt-auto pt-10">{b}</p>
            </Reveal>
          ))}
        </div>
      </Section>
    </>
  );
}