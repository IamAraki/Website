import { Outlet } from 'react-router-dom';
import Nav from './Nav';
import Footer from './Footer';

export default function SiteLayout() {
  return (
    <div className="min-h-screen bg-cloud text-ink overflow-x-hidden">
      <Nav />
      <main><Outlet /></main>
      <Footer />
    </div>
  );
}