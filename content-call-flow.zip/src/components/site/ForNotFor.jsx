import { Reveal, Section } from './Primitives';

export default function ForNotFor({ label = 'Who it is for', forTitle = 'For', notTitle = 'Not for', forText, notText }) {
  return (
    <Section className="!pt-0">
      <p className="label mb-8">{label}</p>
      <div className="grid md:grid-cols-2 gap-4">
        <Reveal className="card p-8 md:p-10 h-full">
          <p className="label mb-6 inline-block bg-sky rounded-full px-3 py-1">{forTitle}</p>
          <p className="body-lg">{forText}</p>
        </Reveal>
        <Reveal delay={0.1} className="rounded-[24px] border border-ink/10 bg-lilac/30 p-8 md:p-10 h-full">
          <p className="label mb-6 inline-block bg-white rounded-full px-3 py-1">{notTitle}</p>
          <p className="body-lg">{notText}</p>
        </Reveal>
      </div>
    </Section>
  );
}