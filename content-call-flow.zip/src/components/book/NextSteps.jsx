const steps = [
  ['Apply', 'Fill in the short application.'],
  ['Qualification call', 'We check if we are a fit. This is not a pressure call.'],
  ['Plan', 'If it is a fit, we show you the 30/60/90 plan and the price.'],
  ['Onboard', 'Welcome message within 24 hours of payment, onboarding call within 3 business days.'],
];
const signs = ['Working $2,000+ offer', 'Some proof or reviews', 'A sales process', 'Willingness to film one day a month', 'Clear goals'];

export default function NextSteps() {
  return (
    <aside className="lg:sticky lg:top-32 space-y-4">
      <p className="label mb-6">What happens next</p>
      <ol className="space-y-6 mb-10">
        {steps.map(([t, d], i) => (
          <li key={t} className="flex gap-4">
            <span className="w-10 h-10 shrink-0 rounded-full bg-lilac grid place-items-center font-bold body-sm">{i + 1}</span>
            <div><p className="body-lg font-bold">{t}</p><p className="body-sm mt-1">{d}</p></div>
          </li>
        ))}
      </ol>
      <div className="rounded-[20px] border border-ink/15 p-6 bg-white">
        <p className="label mb-3">The call</p>
        <p className="body-sm">Rapport (3 to 5 minutes), discovery questions (about 20 minutes), the plan, then price and next steps. We follow up in 2 to 3 days with new value, such as a short audit of your profile, if you need time.</p>
      </div>
      <div className="rounded-[20px] border border-ink/15 p-6 bg-sky/30">
        <p className="label mb-3">Great fit signs</p>
        <ul className="space-y-1">{signs.map((s) => <li key={s} className="body-sm">· {s}</li>)}</ul>
      </div>
    </aside>
  );
}