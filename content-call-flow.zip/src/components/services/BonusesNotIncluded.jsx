import { X } from 'lucide-react';
import { Label, Reveal, Section } from '@/components/site/Primitives';
import { bonuses, notIncluded } from '@/lib/servicesContent';

export default function BonusesNotIncluded() {
  return (
    <Section className="!pt-0">
      <div className="grid lg:grid-cols-2 gap-12">
        <div>
          <Label>Bonuses</Label>
          <div className="grid gap-4">
            {bonuses.map(([t, s, v]) => (
              <Reveal key={t} className="rounded-[24px] bg-lilac p-8">
                <div className="flex justify-between gap-6 items-start">
                  <p className="sub">{t}</p>
                  <p className="label !mb-0 bg-white rounded-full px-3 py-1 shrink-0">Value {v}</p>
                </div>
                <p className="body-lg mt-6"><span className="font-bold">Solves:</span> {s}</p>
              </Reveal>
            ))}
          </div>
        </div>
        <div>
          <Label>Not included</Label>
          <ul>
            {notIncluded.map((n) => (
              <li key={n} className="flex gap-4 items-center py-4 border-b border-ink/15 body-lg">
                <span className="w-6 h-6 rounded-full border border-ink/40 grid place-items-center shrink-0"><X size={12} aria-hidden="true" /></span>{n}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Section>
  );
}