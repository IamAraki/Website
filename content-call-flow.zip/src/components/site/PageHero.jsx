import { motion } from 'framer-motion';
import { PillLink } from './Primitives';

export default function PageHero({ label, title, sub, cta = true }) {
  return (
    <section className="relative px-5 md:px-10 pt-44 md:pt-52 pb-[76px]">
      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="mx-auto max-w-[1400px]">
        <p className="label mb-8">{label}</p>
        <h1 className="display max-w-[1200px]">{title}</h1>
        <p className="body-lg mt-10 max-w-[640px]">{sub}</p>
        {cta && <PillLink className="mt-10" />}
      </motion.div>
    </section>
  );
}