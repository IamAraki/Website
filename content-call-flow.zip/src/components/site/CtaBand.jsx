import { Circles, PillLink, Reveal, Section } from './Primitives';

export default function CtaBand() {
  return (
    <Section className="!pt-0">
      <Reveal className="relative overflow-hidden rounded-[28px] bg-sky px-6 md:px-16 py-16 md:py-24">
        <Circles className="w-[700px] h-[700px] -right-48 -top-40" />
        <h2 className="relative h-lg max-w-[1000px]">You film once a month. We do the rest.</h2>
        <PillLink className="relative mt-12" />
      </Reveal>
    </Section>
  );
}