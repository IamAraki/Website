import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Placeholder } from '@/components/site/Primitives';
import { Field, Choice } from './Field';

const text = [
  ['name', 'Name'], ['instagram', 'Instagram handle'], ['website', 'Website'],
  ['offer_and_price', 'What do you sell, and at what price?'],
];
const revenue = ['Under $10K', '$10K to $50K', '$50K to $100K', 'Over $100K'];
const closes = ['I close my own calls', 'I work with a closer', 'Other'];
const invest = [['Yes', 'Yes'], ['No', 'No'], ['Founding client rate', 'Founding client rate of $2,500 per month applies to the first 3 clients']];
const required = ['name', 'instagram', 'website', 'offer_and_price', 'monthly_revenue', 'calls_and_close_rate', 'tried_and_result', 'who_closes', 'willing_to_film', 'ready_to_invest', 'email'];

export default function ApplicationForm() {
  const [v, setV] = useState({});
  const [errors, setErrors] = useState({});
  const [state, setState] = useState('idle');
  const set = (k) => (val) => {
    setV((p) => ({ ...p, [k]: val }));
    setErrors((p) => ({ ...p, [k]: undefined }));
  };
  const input = (k) => ({ id: k, value: v[k] || '', onChange: (e) => set(k)(e.target.value), className: 'field', 'aria-invalid': !!errors[k] });

  const submit = async (e) => {
    e.preventDefault();
    const errs = {};
    required.forEach((k) => { if (!String(v[k] || '').trim()) errs[k] = k === 'willing_to_film' || k === 'ready_to_invest' || k === 'monthly_revenue' || k === 'who_closes' ? 'Please choose an option.' : 'Please fill this in.'; });
    if (v.email && !/^\S+@\S+\.\S+$/.test(v.email)) errs.email = 'Please enter a valid email address.';
    setErrors(errs);
    if (Object.keys(errs).length) return document.getElementById(Object.keys(errs)[0])?.focus();
    setState('sending');
    try {
      await base44.entities.Application.create({ ...v, status: v.willing_to_film === 'No' ? 'Not a fit' : 'New' });
      setState('done');
    } catch {
      setState('idle');
      setErrors({ form: 'Something went wrong. Please try again.' });
    }
  };

  if (state === 'done') return (
    <div className="card p-8 md:p-12" role="status">
      <h2 className="h-sm">Application received.</h2>
      <p className="body-lg mt-6">We will review it and send your call link soon.</p>
      <div className="mt-10 rounded-[20px] border border-dashed border-ink/30 p-10 text-center"><Placeholder>[PLACEHOLDER: CALENDAR LINK]</Placeholder></div>
    </div>
  );

  return (
    <form onSubmit={submit} noValidate className="card p-6 md:p-10 space-y-7">
      {text.map(([k, l]) => <Field key={k} id={k} label={l} error={errors[k]}><input {...input(k)} /></Field>)}
      <Field id="monthly_revenue" label="What is your monthly revenue?" error={errors.monthly_revenue}>
        <select {...input('monthly_revenue')}><option value="">Select…</option>{revenue.map((r) => <option key={r}>{r}</option>)}</select>
      </Field>
      <Field id="calls_and_close_rate" label="How many calls do you book a month, and how many close?" error={errors.calls_and_close_rate}><input {...input('calls_and_close_rate')} /></Field>
      <Field id="tried_and_result" label="What have you tried to grow, and what happened?" error={errors.tried_and_result}><textarea rows={4} {...input('tried_and_result')} /></Field>
      <Field id="who_closes" label="Who closes your calls?" error={errors.who_closes}>
        <select {...input('who_closes')}><option value="">Select…</option>{closes.map((r) => <option key={r}>{r}</option>)}</select>
      </Field>
      <Field id="willing_to_film" label="Are you willing to film one day a month?" error={errors.willing_to_film}
        note={v.willing_to_film === 'No' && <span className="inline-block bg-lime/40 rounded-md px-2 py-1">This system needs one filming day a month to work.</span>}>
        <Choice name="willing_to_film" options={[['Yes', 'Yes'], ['No', 'No']]} value={v.willing_to_film} onChange={set('willing_to_film')} />
      </Field>
      <Field id="ready_to_invest" label="Are you ready to invest $5,000 per month for at least 3 months?" error={errors.ready_to_invest}>
        <Choice name="ready_to_invest" options={invest} value={v.ready_to_invest} onChange={set('ready_to_invest')} />
      </Field>
      <Field id="email" label="Email (needed to send the booking link)" error={errors.email}><input type="email" {...input('email')} /></Field>
      {errors.form && <p className="body-sm text-destructive">{errors.form}</p>}
      <button type="submit" disabled={state === 'sending'} className="btn-pill w-full sm:w-auto">{state === 'sending' ? 'Submitting…' : 'Submit Application →'}</button>
    </form>
  );
}